# openrouter-selector

LLM connection using OpenRouter with a single library.
